<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Fusion
 */

?>

<article>
	
	<!-- Services Sections Start-->
	<section class="fold2">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="yelo_vertic_line"></div>
					<div class="yelo_sub_heading">Our Services</div>
					<h2 class="heading2">Our team will take your business <br>presence to new level</h2>
				</div>
			</div>
			<div class="row">
				<div class="col-md-4 col-sm-12">
					<div class="serv_box">
						<div class="icon"><img src="http://parssyio.com/fusion/wp-content/uploads/2021/03/srategy-1.png"/></div>
						<div class="title">Strategy.</div>
						<div class="desc">Ship it user story iterate engaging <br>co-working intuitive pitch deck hacker prototype SpaceTeam user centered design big data.</div>
						<a class="cta_getintouch" href="">See Details <img src="http://parssyio.com/fusion/wp-content/uploads/2021/03/right-arrow.png"></a>
					</div>
				</div>

				<div class="col-md-4 col-sm-12">
					<div class="serv_box">
						<div class="icon"><img src="http://parssyio.com/fusion/wp-content/uploads/2021/03/branding.png"/></div>
						<div class="title">Branding.</div>
						<div class="desc">Ship it user story iterate engaging co-working intuitive pitch deck hacker prototype SpaceTeam user centered design big data.</div>
						<a class="cta_getintouch" href="">See Details <img src="http://parssyio.com/fusion/wp-content/uploads/2021/03/right-arrow.png"></a>
					</div>
				</div>

				<div class="col-md-4 col-sm-12">
					<div class="serv_box">
						<div class="icon"><img src="http://parssyio.com/fusion/wp-content/uploads/2021/03/design.png"/></div>
						<div class="title">Design.</div>
						<div class="desc">Ship it user story iterate engaging co-working intuitive pitch deck hacker prototype SpaceTeam user centered design big data.</div>
						<a class="cta_getintouch" href="">See Details <img src="http://parssyio.com/fusion/wp-content/uploads/2021/03/right-arrow.png"></a>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Services Sections End-->




	<!-- Branding & Design Start-->
	<section class="fold3">
		<div class="container">
			<div class="row">
				<div class="col-md-2 col-sm-12">
					<div class="yelo_vertic_line"></div>
					<div class="yelo_sub_heading align_l">Branding & Design</div>
					<h2 class="heading2 big">Project One</h2>
				</div>
				<div class="col-md-8 col-sm-12">
					<div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
					  <div class="carousel-indicators">
						<button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
						<button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
						<button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
						<button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="3" aria-label="Slide 4"></button>
						<button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="4" aria-label="Slide 5"></button>
					  </div>
					  <div class="carousel-inner">
						<div class="carousel-item active">
						  <img src="http://parssyio.com/fusion/wp-content/uploads/2021/03/slide1.jpg" class="d-block w-100" alt="...">
						</div>
						<div class="carousel-item">
						  <img src="http://parssyio.com/fusion/wp-content/uploads/2021/03/slide1.jpg" class="d-block w-100" alt="...">
						</div>
						<div class="carousel-item">
						  <img src="http://parssyio.com/fusion/wp-content/uploads/2021/03/slide1.jpg" class="d-block w-100" alt="...">
						</div>
						<div class="carousel-item">
						  <img src="http://parssyio.com/fusion/wp-content/uploads/2021/03/slide1.jpg" class="d-block w-100" alt="...">
						</div>
						<div class="carousel-item">
						  <img src="http://parssyio.com/fusion/wp-content/uploads/2021/03/slide1.jpg" class="d-block w-100" alt="...">
						</div>
					  </div>
					</div>
				</div>
				<div class="col-md-2 col-sm-12 relative">
					<div class="bnd_cta">
						<a class="cta_getintouch" href="">Project Details <img src="http://parssyio.com/fusion/wp-content/uploads/2021/03/right-arrow.png"></a><br>
						<a class="cta_getintouch" href="">View Slides <img src="http://parssyio.com/fusion/wp-content/uploads/2021/03/right-arrow.png"></a>
						<div class="yelo_vertic_line"></div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Branding & Design Start-->





	<!-- Testimonials Start-->
	<section class="fold2 padding_b100">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="yelo_vertic_line"></div>
					<div class="yelo_sub_heading">Testimonials</div>
					<h2 class="heading2">We have worked with some amazing <br>companies around the world</h2>
				</div>
				<div class="col-md-12">
					<div class="testimo_logos">
						<ul>
							<li><a href=""><img src="http://parssyio.com/fusion/wp-content/uploads/2021/03/testimo-logo1.png"/></a></li>
							<li><a href=""><img src="http://parssyio.com/fusion/wp-content/uploads/2021/03/testimo-logo2.png"/></a></li>
							<li><a href=""><img src="http://parssyio.com/fusion/wp-content/uploads/2021/03/testimo-logo3.png"/></a></li>
							<li><a href=""><img src="http://parssyio.com/fusion/wp-content/uploads/2021/03/testimo-logo4.png"/></a></li>
							<li><a href=""><img src="http://parssyio.com/fusion/wp-content/uploads/2021/03/testimo-logo5.png"/></a></li>
							<li><a href=""><img src="http://parssyio.com/fusion/wp-content/uploads/2021/03/testimo-logo6.png"/></a></li>
							<li><a href=""><img src="http://parssyio.com/fusion/wp-content/uploads/2021/03/testimo-logo7.png"/></a></li>
						</ul>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-2 col-sm-12"></div>
				<div class="col-md-8 col-sm-12">
					<div id="carouselExampleIndicators" class="carousel slide testimo_slide" data-bs-ride="carousel">
					  <div class="carousel-indicators">
						<button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
						<button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
						<button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
					  </div>
					  <div class="carousel-inner">
						<div class="carousel-item active">
							<div class="pic"><img src="http://parssyio.com/fusion/wp-content/uploads/2021/03/profile.png"/></div>
							<div class="text"><p><em>“These cartridges can be replaced by the printer ink of similar brand. Compatible Inkjet Cartridge will help you to make extra-ordinary savings with money back guarantee. As soon as the cartridge gets empty the ink that it contains begins to dry”</em></p></div>
							
							<div class="testimo_name">
								<div class="hr_line"></div>
								<div>Anthony Watkins</div>
								<p>VP of Product, VISA</p>
							</div>
						</div>
						<div class="carousel-item">
							<div class="pic"><img src="http://parssyio.com/fusion/wp-content/uploads/2021/03/profile.png"/></div>
							<div class="text"><p><em>“These cartridges can be replaced by the printer ink of similar brand. Compatible Inkjet Cartridge will help you to make extra-ordinary savings with money back guarantee. As soon as the cartridge gets empty the ink that it contains begins to dry”</em></p></div>
							<div class="testimo_name">
								<div class="hr_line"></div>
								<div>Anthony Watkins</div>
								<p>VP of Product, VISA</p>
							</div>
						</div>
						<div class="carousel-item">
							<div class="pic"><img src="http://parssyio.com/fusion/wp-content/uploads/2021/03/profile.png"/></div>
							<div class="text"><p><em>“These cartridges can be replaced by the printer ink of similar brand. Compatible Inkjet Cartridge will help you to make extra-ordinary savings with money back guarantee. As soon as the cartridge gets empty the ink that it contains begins to dry”</em></p></div>
							<div class="testimo_name">
								<div class="hr_line"></div>
								<div>Anthony Watkins</div>
								<p>VP of Product, VISA</p>
							</div>
						</div>
					  </div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Testimonials End-->




	<!-- Team Start-->
	<section class="fold2 dark">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="yelo_vertic_line"></div>
					<div class="yelo_sub_heading">Our Team</div>
					<h2 class="heading2">Our Amazing Team</h2>
				</div>
			</div>
			<div class="row padding_tb100">
				<div class="col-md-3 col-sm-6 col-xs-12 indivisual_prof">
					<div class="front_profile">
						<div class="pic"><img src="http://parssyio.com/fusion/wp-content/uploads/2021/03/profile.png"/></div>
						<div class="name">
							<div>Anthony Watkins</div>
							<p>VP of Product, VISA</p>
						</div>
					</div>
					<div class="details_profile">
						<div class="profile">
							<div class="pic"><img src="http://parssyio.com/fusion/wp-content/uploads/2021/03/profile.png"/></div>
							<div class="name">
								<div>Anthony Watkins</div>
								<p>VP of Product, VISA</p>
							</div>
						</div>
						<div class="details">
							Vincent is the Founder & CEO of Fusion. He is leading  the company to success with his experience & skill. Leader piverate paradigm cortado ship it integrate Space Team parallax persons grok. Parallax food truck fund 360 campaign venture capital pitch deck actionable insight innovate.
						</div>
					</div>
				</div>
				<div class="col-md-3 col-sm-6 col-xs-12 indivisual_prof">
					<div class="front_profile">
						<div class="pic"><img src="http://parssyio.com/fusion/wp-content/uploads/2021/03/profile.png"/></div>
						<div class="name">
							<div>Donna Watson</div>
							<p>VP of Product</p>
						</div>
					</div>
					<div class="details_profile">
						<div class="profile">
							<div class="pic"><img src="http://parssyio.com/fusion/wp-content/uploads/2021/03/profile.png"/></div>
							<div class="name">
								<div>Donna Watson</div>
								<p>VP of Product</p>
							</div>
						</div>
						<div class="details">
							Vincent is the Founder & CEO of Fusion. He is leading  the company to success with his experience & skill. Leader piverate paradigm cortado ship it integrate Space Team parallax persons grok. Parallax food truck fund 360 campaign venture capital pitch deck actionable insight innovate.
						</div>
					</div>
				</div>
				<div class="col-md-3 col-sm-6 col-xs-12 indivisual_prof">
					<div class="front_profile">
						<div class="pic"><img src="http://parssyio.com/fusion/wp-content/uploads/2021/03/profile.png"/></div>
						<div class="name">
							<div>Armando Ángeles</div>
							<p>VP of Business</p>
						</div>
					</div>
					<div class="details_profile">
						<div class="profile">
							<div class="pic"><img src="http://parssyio.com/fusion/wp-content/uploads/2021/03/profile.png"/></div>
							<div class="name">
								<div>Armando Ángeles</div>
								<p>VP of Business</p>
							</div>
						</div>
						<div class="details">
							Vincent is the Founder & CEO of Fusion. He is leading  the company to success with his experience & skill. Leader piverate paradigm cortado ship it integrate Space Team parallax persons grok. Parallax food truck fund 360 campaign venture capital pitch deck actionable insight innovate.
						</div>
					</div>
				</div>
				<div class="col-md-3 col-sm-6 col-xs-12 indivisual_prof">
					<div class="front_profile border_rn">
						<div class="pic"><img src="http://parssyio.com/fusion/wp-content/uploads/2021/03/profile.png"/></div>
						<div class="name">
							<div>Nguyễn Thanh</div>
							<p>Developer</p>
						</div>
					</div>
					<div class="details_profile">
						<div class="profile">
							<div class="pic"><img src="http://parssyio.com/fusion/wp-content/uploads/2021/03/profile.png"/></div>
							<div class="name">
								<div>Nguyễn Thanh</div>
								<p>Developer</p>
							</div>
						</div>
						<div class="details">
							Vincent is the Founder & CEO of Fusion. He is leading  the company to success with his experience & skill. Leader piverate paradigm cortado ship it integrate Space Team parallax persons grok. Parallax food truck fund 360 campaign venture capital pitch deck actionable insight innovate.
						</div>
					</div>
				</div>
				<div class="col-md-3 col-sm-6 col-xs-12 indivisual_prof">
					<div class="front_profile border_bn">
						<div class="pic"><img src="http://parssyio.com/fusion/wp-content/uploads/2021/03/profile.png"/></div>
						<div class="name">
							<div>Armando Ángeles</div>
							<p>VP of Business</p>
						</div>
					</div>
					<div class="details_profile">
						<div class="profile">
							<div class="pic"><img src="http://parssyio.com/fusion/wp-content/uploads/2021/03/profile.png"/></div>
							<div class="name">
								<div>Armando Ángeles</div>
								<p>VP of Business</p>
							</div>
						</div>
						<div class="details">
							Vincent is the Founder & CEO of Fusion. He is leading  the company to success with his experience & skill. Leader piverate paradigm cortado ship it integrate Space Team parallax persons grok. Parallax food truck fund 360 campaign venture capital pitch deck actionable insight innovate.
						</div>
					</div>
				</div>
				<div class="col-md-3 col-sm-6 col-xs-12 indivisual_prof">
					<div class="front_profile border_bn">
						<div class="pic"><img src="http://parssyio.com/fusion/wp-content/uploads/2021/03/profile.png"/></div>
						<div class="name">
							<div>Donna Watson</div>
							<p>VP of Product</p>
						</div>
					</div>
					<div class="details_profile">
						<div class="profile">
							<div class="pic"><img src="http://parssyio.com/fusion/wp-content/uploads/2021/03/profile.png"/></div>
							<div class="name">
								<div>Donna Watson</div>
								<p>VP of Product</p>
							</div>
						</div>
						<div class="details">
							Vincent is the Founder & CEO of Fusion. He is leading  the company to success with his experience & skill. Leader piverate paradigm cortado ship it integrate Space Team parallax persons grok. Parallax food truck fund 360 campaign venture capital pitch deck actionable insight innovate.
						</div>
					</div>
				</div>
				<div class="col-md-3 col-sm-6 col-xs-12 indivisual_prof">
					<div class="front_profile border_bn">
						<div class="pic"><img src="http://parssyio.com/fusion/wp-content/uploads/2021/03/profile.png"/></div>
						<div class="name">
							<div>Armando Ángeles</div>
							<p>VP of Business</p>
						</div>
					</div>
					<div class="details_profile">
						<div class="profile">
							<div class="pic"><img src="http://parssyio.com/fusion/wp-content/uploads/2021/03/profile.png"/></div>
							<div class="name">
								<div>Armando Ángeles</div>
								<p>VP of Business</p>
							</div>
						</div>
						<div class="details">
							Vincent is the Founder & CEO of Fusion. He is leading  the company to success with his experience & skill. Leader piverate paradigm cortado ship it integrate Space Team parallax persons grok. Parallax food truck fund 360 campaign venture capital pitch deck actionable insight innovate.
						</div>
					</div>
				</div>
				<div class="col-md-3 col-sm-6 col-xs-12 indivisual_prof">
					<div class="front_profile border_rbn">
						<div class="pic"><img src="http://parssyio.com/fusion/wp-content/uploads/2021/03/profile.png"/></div>
						<div class="name">
							<div>Nguyễn Thanh</div>
							<p>Developer</p>
						</div>
					</div>
					<div class="details_profile">
						<div class="profile">
							<div class="pic"><img src="http://parssyio.com/fusion/wp-content/uploads/2021/03/profile.png"/></div>
							<div class="name">
								<div>Nguyễn Thanh</div>
								<p>Developer</p>
							</div>
						</div>
						<div class="details">
							Vincent is the Founder & CEO of Fusion. He is leading  the company to success with his experience & skill. Leader piverate paradigm cortado ship it integrate Space Team parallax persons grok. Parallax food truck fund 360 campaign venture capital pitch deck actionable insight innovate.
						</div>
					</div>
				</div>
				
			</div>
		</div>
	</section>
	<!-- Team Start-->


	<!-- Contact Form Start-->
	<section class="fold2 foot padding_b100">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="yelo_vertic_line"></div>
					<div class="yelo_sub_heading">Contact us</div>
					<h2 class="heading2">Let’s talk about the project</h2>
				</div>
			</div>
			<div class="row">
				<div class="col-md-2 col-sm-12"></div>
				<div class="col-md-8 col-sm-12">
					<div class="wpforms-container wpforms-container-full contact_form" id="wpforms-227">
						<form id="wpforms-form-227" class="wpforms-validate wpforms-form" data-formid="227" method="post" enctype="multipart/form-data" action="http://parssyio.com/fusion/?wpforms_form_preview=227" data-token="71eef1d57fa36ed0bb5171e7e9ec6fcb" novalidate="novalidate">
							<noscript class="wpforms-error-noscript">Please enable JavaScript in your browser to complete this form.</noscript>
							<div class="wpforms-field-container">
								<div id="wpforms-227-field_3-container" class="wpforms-field wpforms-field-name wpforms-one-half wpforms-first" data-field-id="3"><label class="wpforms-field-label" for="wpforms-227-field_3">Name <span class="wpforms-required-label"></span></label><input type="text" id="wpforms-227-field_3" class="wpforms-field-medium wpforms-field-required" name="wpforms[fields][3]" required=""></div>
								
								<div id="wpforms-227-field_1-container" class="wpforms-field wpforms-field-email wpforms-one-half" data-field-id="1"><label class="wpforms-field-label" for="wpforms-227-field_1">Email <span class="wpforms-required-label"></span></label><input type="email" id="wpforms-227-field_1" class="wpforms-field-medium wpforms-field-required" name="wpforms[fields][1]" required=""></div>

								<div id="wpforms-227-field_4-container" class="wpforms-field wpforms-field-text wpforms-one-half wpforms-first" data-field-id="4"><label class="wpforms-field-label" for="wpforms-227-field_4">Company <span class="wpforms-required-label"></span></label><input type="text" id="wpforms-227-field_4" class="wpforms-field-medium wpforms-field-required" name="wpforms[fields][4]" required=""></div>

								<div id="wpforms-227-field_5-container" class="wpforms-field wpforms-field-text wpforms-one-half" data-field-id="5"><label class="wpforms-field-label" for="wpforms-227-field_5">Subject <span class="wpforms-required-label"></span></label><input type="text" id="wpforms-227-field_5" class="wpforms-field-medium wpforms-field-required" name="wpforms[fields][5]" required=""></div>
								
								<div id="wpforms-227-field_2-container" class="wpforms-field wpforms-field-textarea" data-field-id="2"><label class="wpforms-field-label" for="wpforms-227-field_2">Message <span class="wpforms-required-label"></span></label><textarea id="wpforms-227-field_2" class="wpforms-field-medium wpforms-field-required" name="wpforms[fields][2]" required=""></textarea></div>
							</div>
							<div class="wpforms-submit-container"><input type="hidden" name="wpforms[id]" value="227"><input type="hidden" name="wpforms[author]" value="1"><input type="hidden" name="wpforms[post_id]" value="75"><button type="submit" name="wpforms[submit]" class="wpforms-submit " id="wpforms-submit-227" value="wpforms-submit" aria-live="assertive" data-alt-text="Sending..." data-submit-text="Get In Touch">Get In Touch</button></div>
						</form>
					</div>



					<!--<div class="contact_form">
						<form class="row g-3 needs-validation" novalidate>
							<div class="col-md-6 position-relative">
								<label for="validationTooltip01" class="form-label">First name</label>
								<input type="text" class="form-control" id="validationTooltip01" value="" required>
								<div class="valid-tooltip">
								  Looks good!
								</div>
							</div>
							<div class="col-md-6 position-relative">
								 <label for="exampleInputEmail1" class="form-label">Email address</label>
								<input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="" required>
								<div class="valid-tooltip">
								  Looks good!
								</div>
							</div>
							<div class="col-md-6 position-relative">
								<label for="company" class="form-label">Company</label>
								<input type="text" class="form-control" id="company" placeholder="">
								<div class="valid-tooltip">
								  Looks good!
								</div>
							</div>
							<div class="col-md-6 position-relative">
								<label for="subject" class="form-label">Subject</label>
								<input type="text" class="form-control" id="subject" placeholder="">
								<div class="valid-tooltip">
								  Looks good!
								</div>
							</div>

							<div class="col-md-12 position-relative">
								<label for="yourmessage" class="form-label">Your Message</label>
								<input type="textarea" class="form-control" id="yourmessage" placeholder="">
								<div class="valid-tooltip">
								  Looks good!
								</div>
							</div>
							 
						  <div class="col-12">
							<button class="btn btn-primary" type="submit">Submit form</button>
						  </div>
						</form>
					</div>-->
				</div>
				
			</div>
		</div>
	</section>
	<!-- Contact Form End-->



	<footer class="entry-footer">
		<?php parssyio_fusion_entry_footer(); ?>
	</footer><!-- .entry-footer -->
</article><!-- #post-<?php the_ID(); ?> -->
