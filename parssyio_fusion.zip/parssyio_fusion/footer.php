<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Fusion
 */

?>
<section class="fold2 foot">
	<footer id="colophon" class="site-footer container">
		<div class="row">
			<div class="col-md-2  col-sm-12">
				<img src="http://parssyio.com/fusion/wp-content/uploads/2021/03/cropped-fustion-logo.png" class="custom-logo" alt="The Fusion">
			</div>
			<div class="col-md-3 col-sm-12">
				<h4>California Office</h4>
				<p>4243 Woodland Terrace<br>
					Sacramento, CA 95814<br>
					916 753 2645</p>
			</div>
			<div class="col-md-3 col-sm-12">
				<h4>New York Office </h4>
				<p>885 Oakwood Avenue<br>
					New York, NY 10013<br>
					212 660 0744</p>
			</div>
			<div class="col-md-4 col-sm-12">
				<h4>Other Contact </h4>
				<a href="mailto:jobs@templateocean.com">jobs@templateocean.com</a>
				<ul class="social_links">
					<li><a href=""><img src="http://parssyio.com/fusion/wp-content/uploads/2021/03/fb.png"/></a></li>
					<li><a href=""><img src="http://parssyio.com/fusion/wp-content/uploads/2021/03/twitter.png"/></a></li>
					<li><a href=""><img src="http://parssyio.com/fusion/wp-content/uploads/2021/03/pins.png"/></a></li>
					<li><a href=""><img src="http://parssyio.com/fusion/wp-content/uploads/2021/03/insta.png"/></a></li>
					<li><a href=""><img src="http://parssyio.com/fusion/wp-content/uploads/2021/03/browser.png"/></a></li>
				</ul>
			</div>
		</div>

		<!--<div class="site-info" style="display:none">
			<a href="<?php echo esc_url( __( 'https://wordpress.org/', 'parssyio_fusion' ) ); ?>">
				<?php
				/* translators: %s: CMS name, i.e. WordPress. */
				printf( esc_html__( 'Proudly powered by %s', 'parssyio_fusion' ), 'WordPress' );
				?>
			</a>
			<span class="sep"> | </span>
				<?php
				/* translators: 1: Theme name, 2: Theme author. */
				printf( esc_html__( 'Theme: %1$s by %2$s.', 'parssyio_fusion' ), 'parssyio_fusion', '<a href="http://parssyio.com/fusion/">Parss</a>' );
				?>
		</div><!-- .site-info -->
	</footer><!-- #colophon -->
</section>
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
